
const nav = document.getElementById('nav');
const view = document.getElementById('view');
const themeToggle = document.getElementById('themeToggle');
const topbarTitle = document.getElementById('topbarTitle');

// Dữ liệu các trang (Router đơn giản)
const routes = {
  home: { title: 'Trang chủ', content: '<div class="card"><h2>👋 Chào mừng Quang Huy!</h2><p>Hôm nay bạn muốn học kỹ năng nào? Hãy chọn mục ở menu bên trái nhé.</p></div>' },
  vocab: { title: 'Sổ từ vựng', content: '<div class="card"><h2>📖 Sổ từ vựng IELTS</h2><p>Các từ vựng mới học sẽ được lưu ở đây...</p></div>' },
  practice: { title: 'Thi thử IELTS', content: '<div class="card"><h2>📝 Thi thử</h2><p>Làm bài test Reading và Listening tại đây.</p></div>' }
};

function renderNav() {
  nav.innerHTML = `
    <a href="#home" id="nav-home" class="active">🏠 Trang chủ</a>
    <a href="#vocab" id="nav-vocab">📖 Sổ từ vựng</a>
    <a href="#practice" id="nav-practice">📝 Thi thử</a>
  `;
}

// Hàm chuyển trang
function navigate() {
  let hash = window.location.hash.substring(1);
  if (!routes[hash]) hash = 'home';
  
  view.innerHTML = routes[hash].content;
  topbarTitle.innerText = routes[hash].title;
  
  // Update class active cho menu
  document.querySelectorAll('.nav a').forEach(el => el.classList.remove('active'));
  document.getElementById('nav-' + hash).classList.add('active');
}

// Chế độ sáng tối
themeToggle.addEventListener('click', () => {
  const currentTheme = document.body.getAttribute('data-theme');
  document.body.setAttribute('data-theme', currentTheme === 'dark' ? 'light' : 'dark');
});

// Khởi tạo
renderNav();
window.addEventListener('hashchange', navigate);
navigate(); // Load lần đầu
